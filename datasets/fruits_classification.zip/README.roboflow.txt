
Fruits Dataset - v2 raw
==============================

This dataset was exported via roboflow.ai on April 10, 2020 at 9:19 PM GMT

It includes 2911 images.
Fruit are annotated in folder format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


