
Flowers_Classification - v2 raw
==============================

This dataset was exported via roboflow.ai on September 5, 2020 at 5:57 AM GMT

It includes 1821 images.
Flowers are annotated in folder format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


